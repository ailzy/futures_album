# -*- coding:utf-8 -*-

import os, pickle
import numpy as np
from symbol import symbol2info
from rqalpha.api import *
from rqalpha import run_func
from modeldata import DataCache
from modelmgr import ModelMgr
from portfolio import Portfolio

def init(context):
    context.symbol2info = symbol2info
    context.symbol_list = symbol2info.keys()#[0:10]

    context.symbol_lnn = len(context.symbol_list)
    context.counter = 0
    context.window = 150
    context.coef = 0.3
    context.datacache = DataCache()
    subscribe(context.symbol_list)

def before_trading(context):
    # context.counter = 0
    pass

def handle_bar(context, bar_dict):
    position_list = [context.portfolio.positions[symbol]
                     for symbol in context.symbol_list]

    print(context.now)

    bs_quantity_list = [(position.buy_quantity, position.sell_quantity)
                        for position in position_list]

    context.counter += 1

    price_array_list = [history_bars(_, context.window, '1d', 'close')
                        for _ in context.symbol_list]

    this_date = context.now

    price_list = [price_array[-1] for price_array in price_array_list]

    print("price_list is %s" % str(price_list))
    context.datacache.update_data(this_date, price_list)

    # calculate proportion

    symbol_proportion = [price * float(context.symbol2info[key][0])
                         for key, price in list(zip(context.symbol_list, price_list))]
    symbol_money = [price * float(context.symbol2info[key][0]) * \
                    float(context.symbol2info[key][1]) \
                    for key, price in list(zip(context.symbol_list, price_list))]

    bs_money_list = [money * (num_arr[0] - num_arr[1])
                     for money, num_arr in list(zip(symbol_money, bs_quantity_list))]

    bs_money_sum = sum([abs(money) for money in bs_money_list])

    if bs_money_sum > 0:
        last_asset_weight = [money / bs_money_sum for money in bs_money_list]
    else:
        last_asset_weight = [0 for i in range(len(bs_money_list))]

    print("last bs quantity list is %s" % str(bs_quantity_list))
    print("last asset weight is %s" % str(last_asset_weight))

    symbol_prop_normalized = [_ / sum(symbol_proportion) for _ in symbol_proportion]

    if context.counter > context.window and context.counter % 5 == 0:
        ret, riskcov_ep = None, None
        if os.path.exists('./data/model/%s' % context.now):
            with open('./data/model/%s' % context.now, 'rb') as f:
                ret, riskcov_ep = pickle.load(f)
        else:
            modelmgr = ModelMgr(context.now, context.datacache, context.window, [5, 10, 15, 20, 25, 30])
            modelmgr.build()
            ret, riskcov_ep = modelmgr.ret, modelmgr.riskcov_ep
            with open('./data/model/%s' % context.now, 'wb') as f:
                pickle.dump([ret, riskcov_ep], f)

        # print "ret is %s" % str(ret)

        asset_weight = None
        try:
            asset_weight = Portfolio(last_asset_weight,
                                     context.symbol_lnn,
                                     ret,
                                     riskcov_ep,
                                     risk_thres=200,
                                     w_constraint=0.5).asset_weight
            print("Portfolio Succeed!")
        except:
            asset_weight = None
            print("Portfolio Failed!")

        if asset_weight is None:
            asset_weight = last_asset_weight

        num_trans = []
        sum_money = 0.0

        for i, weight in enumerate(asset_weight):
            rate = weight / symbol_prop_normalized[i]
            if -1e-5 < rate < 1e-5:
                rate = 0
            sum_money += abs(rate) * symbol_money[i]
            num_trans.append(rate)

        # print context.portfolio.cash

        if sum_money > 0:
            trans_multiplier = context.portfolio.cash / sum_money * context.coef
        else:
            trans_multiplier = 0

        print(num_trans)

        num_trans = [int(num * trans_multiplier) for num in num_trans]

        print(num_trans)

        for num, symbol, position in list(zip(num_trans,
                                              context.symbol_list,
                                              position_list)):
            buy_quantity = position.buy_quantity
            sell_quantity = position.sell_quantity

            if num <= 0:
                if buy_quantity > 0:
                    sell_close(symbol, buy_quantity)

                if num < 0:
                    gap_num = abs(num) - sell_quantity

                    if gap_num < 0:
                        buy_close(symbol, abs(gap_num))
                    elif gap_num > 0:
                        sell_open(symbol, gap_num)

            if num >= 0:
                if sell_quantity > 0:
                    buy_close(symbol, sell_quantity)

                if num > 0:
                    gap_num = num - buy_quantity

                    if gap_num < 0:
                        sell_close(symbol, abs(gap_num))
                    elif gap_num > 0:
                        buy_open(symbol, gap_num)

config = {
    "base": {
        "securities": "future",
        "start_date": "2014-01-01",
        "end_date": "2016-12-31",
        "frequency": "1d",
        "matching_type": "current_bar",
        "future_starting_cash": 100000000,
        # "benchmark": "RB1701"
    },
    "extra": {
        "log_level": "debug",
    },
    "mod": {
        "sys_analyser": {
            "enabled": True,
            "plot": True
        },
    },
}

run_func(init=init, handle_bar=handle_bar, config=config)
