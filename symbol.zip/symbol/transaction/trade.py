
class Trade:
    def __init__(self, symbol_list):
        self._symbol_list = symbol_list

