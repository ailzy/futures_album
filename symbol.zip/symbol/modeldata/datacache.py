
"""
DataCache
====================================
A cache for collecting callback data
"""

class DataCache:
    def __init__(self):
        self._mode = None
        self._date_list = []
        self._future_value_list_list = []

    def update_data(self, date, future_value_list):
        self._date_list += [date]
        self._future_value_list_list += [future_value_list]

    @property
    def date_list(self):
        return self._date_list

    def __len__(self):
        return len(self._date_list)

    @property
    def value_matrix(self):
        ''' daily for each column
        :return:
        '''
        return self._future_value_list_list

    @property
    def value_matrix_transpose(self):
        ''' symbol for each column
        :return:
        '''
        return list(zip(*self._future_value_list_list))
