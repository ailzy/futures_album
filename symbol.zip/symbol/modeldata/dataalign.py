
from datastack import DataStack

class DataAlign:
    def __init__(self, datastack, window=120):
        assert (isinstance(datastack, DataStack))
        self._datastack = datastack
        self._date_list = []
        self._Y_matrix = []
        self._X_matrix = []
        self._X_matrix_remain = []
        self._date_list_remain = []
        self._lookback_window = window
        self._build()

    def _build(self):
        target_date_list = self._datastack.target_date_list
        target_value_matrix = self._datastack.target_value_matrix
        talib_indicator_date_list = self._datastack.talib_indicator_date_list
        talib_indicator_value_matrix = self._datastack.talib_indicator_value_matrix

        common_date_set = set(talib_indicator_date_list) & \
                          set(target_date_list)

        self._date_list = sorted(list(common_date_set))
        x_cutoff_date = self._date_list[-1]
        cutoff_idx = 0

        for date, value_vector in list(zip(talib_indicator_date_list,
                                           talib_indicator_value_matrix)):
            if date > x_cutoff_date:
                cutoff_idx += 1

            if date in common_date_set:
                self._X_matrix.append(list(value_vector))

        for date, value_vector in list(zip(target_date_list,
                                           target_value_matrix)):
            if date in common_date_set:
                self._Y_matrix.append(value_vector)

        self._X_matrix_remain = talib_indicator_value_matrix[-cutoff_idx:]
        self._date_list_remain = talib_indicator_date_list[-cutoff_idx:]


        self._date_list = self._date_list[-self._lookback_window:]
        self._X_matrix = self._X_matrix[-self._lookback_window:]
        self._Y_matrix = self._Y_matrix[-self._lookback_window:]

    @property
    def len(self):
        return len(self._date_list)

    @property
    def date_list(self):
        return self._date_list
    @property
    def X_matrix_remain(self):
        return self._X_matrix_remain

    @property
    def date_list_remain(self):
        return self._date_list_remain

    @property
    def Y_matrix(self):
        return self._Y_matrix

    @property
    def X_matrix(self):
        return self._X_matrix

