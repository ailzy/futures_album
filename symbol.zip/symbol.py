# -*- coding:utf-8 -*-

lines_cache = None
symbol2info = dict()

with open('symbol.txt') as f:
    lines_cache = [_.rstrip('\n') for _ in f.readlines()]
    for line in lines_cache[1:]:
        symbol, multiplier, margin, _ = line.split(' ')
        symbol2info[symbol] = [multiplier, margin]

symbol_list = symbol2info.keys()

print symbol2info.keys()

# def get_mp_of_symbol(symbol):
#     return symbol2info[symbol][0]

# def get_mr_of_symbol(symbol):
#     return symbol2info[symbol][1]

# for symbol in symbol_list:
#     print symbol, get_mp_of_symbol(symbol), get_mr_of_symbol(symbol)



